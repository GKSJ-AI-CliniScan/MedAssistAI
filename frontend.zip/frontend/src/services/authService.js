
export const authService = {
  // ======================================================
  // LOGIN WITH EMAIL OR PHONE + ROLE
  // ======================================================

  login: async (credentials) => {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    const { identifier, role, loginMethod } = credentials;

    // Check for existing user in localStorage
    const registeredUsers = JSON.parse(localStorage.getItem("medico_registered_users") || "[]");
    let existingUser = registeredUsers.find(
      (u) => (u.email === identifier || u.phone === identifier) && u.role === role
    );

    let userData;

    if (existingUser) {
      userData = {
        id: existingUser.id,
        name: existingUser.name || `User ${identifier}`,
        email: existingUser.email || identifier,
        phone: existingUser.phone || identifier,
        role: existingUser.role,
        profileCompleted: existingUser.profileCompleted ?? false,
      };
    } else {
      // Create a new temporary user
      userData = {
        id: `UID-${Date.now()}`,
        name: `User ${identifier}`,
        email: loginMethod === "email" ? identifier : "",
        phone: loginMethod === "phone" ? identifier : "",
        role: role,
        profileCompleted: false,
      };
    }

    // ======================================================
    // SAVE SESSION
    // ======================================================

    localStorage.setItem("medico_session", JSON.stringify(userData));

    return {
      user: userData,
    };
  },

  // ======================================================
  // COMPLETE PROFILE
  // ======================================================

  completeProfile: async (userId, profileData) => {
    await new Promise((resolve) => setTimeout(resolve, 800));

    const registeredUsers = JSON.parse(localStorage.getItem("medico_registered_users") || "[]");

    const existingIndex = registeredUsers.findIndex(
      (u) => u.id === userId || u.email === profileData.email || u.phone === profileData.phone
    );

    const userRecord = {
      ...profileData,
      id: userId,
      profileCompleted: true,
    };

    if (existingIndex >= 0) {
      registeredUsers[existingIndex] = userRecord;
    } else {
      registeredUsers.push(userRecord);
    }

    localStorage.setItem("medico_registered_users", JSON.stringify(registeredUsers));
    localStorage.setItem("medico_session", JSON.stringify(userRecord));

    return { user: userRecord };
  },

  // ======================================================
  // LOGOUT
  // ======================================================

  logout: async () => {
    localStorage.removeItem("medico_session");
    return { message: "Logged out" };
  },

  // ======================================================
  // GET CURRENT USER
  // ======================================================

  getMe: async () => {
    const session = localStorage.getItem("medico_session");
    if (!session) {
      throw new Error("Unauthorized");
    }
    return { user: JSON.parse(session) };
  },
};
