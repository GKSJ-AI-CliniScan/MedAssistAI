import { useState } from "react";
import { motion } from "motion/react";
import { ScanHeart, Upload, Loader2, AlertTriangle, CheckCircle, Stethoscope, X, Image as ImageIcon } from "lucide-react";

export default function ImageAnalysis() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [imageType, setImageType] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState(null);

  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0];
    if (uploadedFile && uploadedFile.type.startsWith('image/')) {
      setFile(uploadedFile);
      setPreview(URL.createObjectURL(uploadedFile));
      setResults(null);
    } else {
      alert('Please upload an image file');
    }
  };

  const analyzeImage = async () => {
    if (!file || !imageType) return;

    setIsAnalyzing(true);
    // Simulate AI image analysis
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Mock results based on image type
    const mockResults = {
      predictedDisease: imageType === 'xray' ? "Mild Pneumonia" : 
                       imageType === 'mri' ? "Degenerative Disc Disease" :
                       imageType === 'ct' ? "Small Pulmonary Nodule" : "Normal",
      confidence: Math.floor(Math.random() * 15) + 85,
      imagePreview: preview,
      aiExplanation: imageType === 'xray' ? 
        "The chest X-ray shows mild opacity in the lower right lung field, consistent with early-stage pneumonia. No significant pleural effusion or cardiomegaly observed." :
        imageType === 'mri' ?
        "The MRI scan shows mild degenerative changes in the lumbar spine with disc dehydration at L4-L5 level. No significant neural compression noted." :
        imageType === 'ct' ?
        "The CT scan reveals a small 4mm pulmonary nodule in the right upper lobe. Features suggest benign etiology. No other significant abnormalities." :
        "The image appears within normal limits with no significant pathological findings detected.",
      suggestedSpecialist: imageType === 'xray' ? "Pulmonologist" :
                          imageType === 'mri' ? "Orthopedic Surgeon" :
                          imageType === 'ct' ? "Radiologist" : "General Physician",
      severity: imageType === 'xray' ? "Moderate" : "Low",
      followUpRecommendation: imageType === 'xray' ? "Follow-up X-ray in 2 weeks" :
                               imageType === 'mri' ? "Physical therapy and follow-up in 4 weeks" :
                               imageType === 'ct' ? "Follow-up CT scan in 6 months" : "Routine follow-up"
    };
    
    setResults(mockResults);
    setIsAnalyzing(false);
  };

  const getSeverityColor = (severity) => {
    switch (severity.toLowerCase()) {
      case 'high': return 'bg-red-100 text-red-700 border-red-300';
      case 'moderate': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'low': return 'bg-green-100 text-green-700 border-green-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Medical Image Analysis</h1>
          <p className="text-gray-600">AI-powered medical image analysis for X-rays, MRIs, and CT scans</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upload Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-2xl shadow-sm p-6"
          >
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Upload className="w-5 h-5 text-emerald-600" />
              Upload Medical Image
            </h2>

            {/* Image Type Selection */}
            <div className="mb-4">
              <label className="text-sm font-semibold text-gray-700 block mb-2">Image Type</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { value: 'xray', label: 'Chest X-ray' },
                  { value: 'mri', label: 'MRI' },
                  { value: 'ct', label: 'CT Scan' },
                  { value: 'skin', label: 'Skin Disease' }
                ].map(type => (
                  <button
                    key={type.value}
                    onClick={() => setImageType(type.value)}
                    className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                      imageType === type.value
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-emerald-50'
                    } border`}
                  >
                    {type.label}
                  </button>
                ))}
              </div>
            </div>

            {/* File Upload */}
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-emerald-500 transition-colors">
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="cursor-pointer"
              >
                <ImageIcon className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600 mb-2">Click to upload or drag and drop</p>
                <p className="text-sm text-gray-400">PNG, JPG, JPEG files only</p>
              </label>
            </div>

            {preview && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4"
              >
                <div className="relative">
                  <img
                    src={preview}
                    alt="Preview"
                    className="w-full h-64 object-contain bg-gray-100 rounded-xl"
                  />
                  <button
                    onClick={() => {
                      setFile(null);
                      setPreview(null);
                      setResults(null);
                    }}
                    className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            )}

            <button
              onClick={analyzeImage}
              disabled={!file || !imageType || isAnalyzing}
              className="w-full mt-4 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white py-3 rounded-xl font-semibold hover:from-emerald-700 hover:to-emerald-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Analyzing Image...
                </>
              ) : (
                <>
                  <ScanHeart className="w-5 h-5" />
                  Analyze Image
                </>
              )}
            </button>
          </motion.div>

          {/* Results Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white rounded-2xl shadow-sm p-6"
          >
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <ScanHeart className="w-5 h-5 text-emerald-600" />
              Analysis Results
            </h2>

            {!results ? (
              <div className="text-center py-12 text-gray-500">
                <ScanHeart className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium mb-2">AI-Powered Image Analysis</p>
                <p className="text-sm">Upload a medical image to get AI-powered diagnosis support</p>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Predicted Disease */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-gradient-to-r from-emerald-50 to-emerald-100 rounded-xl border border-emerald-200"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 mb-1">Predicted Disease</h3>
                      <p className="text-2xl font-bold text-emerald-700">{results.predictedDisease}</p>
                    </div>
                    <div className={`px-3 py-1 rounded-xl border ${getSeverityColor(results.severity)}`}>
                      <span className="font-semibold">{results.severity} Severity</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-700">Confidence Score</span>
                        <span className="text-xl font-bold text-emerald-600">{results.confidence}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-emerald-600 h-2 rounded-full transition-all"
                          style={{ width: `${results.confidence}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>

                {/* Image Preview */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="p-4 bg-gray-50 rounded-xl border border-gray-200"
                >
                  <h3 className="font-semibold text-gray-900 mb-3">Analyzed Image</h3>
                  <img
                    src={results.imagePreview}
                    alt="Analyzed"
                    className="w-full h-48 object-contain bg-white rounded-lg"
                  />
                </motion.div>

                {/* AI Explanation */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="p-4 bg-blue-50 rounded-xl border border-blue-200"
                >
                  <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <ScanHeart className="w-5 h-5 text-blue-600" />
                    AI Explanation
                  </h3>
                  <p className="text-sm text-gray-700 leading-relaxed">{results.aiExplanation}</p>
                </motion.div>

                {/* Suggested Specialist */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="p-4 bg-purple-50 rounded-xl border border-purple-200"
                >
                  <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <Stethoscope className="w-5 h-5 text-purple-600" />
                    Suggested Specialist
                  </h3>
                  <p className="text-lg font-bold text-purple-700">{results.suggestedSpecialist}</p>
                </motion.div>

                {/* Follow-up Recommendation */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="p-4 bg-yellow-50 rounded-xl border border-yellow-200"
                >
                  <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    Follow-up Recommendation
                  </h3>
                  <p className="text-sm text-gray-700">{results.followUpRecommendation}</p>
                </motion.div>

                <button
                  onClick={() => {
                    setResults(null);
                    setFile(null);
                    setPreview(null);
                    setImageType("");
                  }}
                  className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
                >
                  Analyze Another Image
                </button>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
