import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { MapPin, Navigation, Phone, Star, Clock, AlertCircle, Loader2, Search, Filter } from "lucide-react";

export default function NearbyHospitals() {
  const [location, setLocation] = useState(null);
  const [hospitals, setHospitals] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterEmergency, setFilterEmergency] = useState(false);

  useEffect(() => {
    // Get user's current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          fetchNearbyHospitals(position.coords.latitude, position.coords.longitude);
        },
        (error) => {
          console.error("Error getting location:", error);
          // Use default location (example: New York)
          setLocation({ lat: 40.7128, lng: -74.0060 });
          fetchNearbyHospitals(40.7128, -74.0060);
        }
      );
    }
  }, []);

  const fetchNearbyHospitals = async (lat, lng) => {
    setIsLoading(true);
    // Simulate API call - in production, use Google Maps Places API
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Mock hospital data
    const mockHospitals = [
      {
        id: 1,
        name: "MedAssist General Hospital",
        address: "123 Healthcare Avenue, Medical District",
        distance: 1.2,
        rating: 4.8,
        reviews: 1250,
        emergencyAvailable: true,
        phone: "+1 (555) 123-4567",
        hours: "24/7 Emergency",
        specialties: ["Cardiology", "Neurology", "Orthopedics"],
        lat: lat + 0.01,
        lng: lng + 0.01
      },
      {
        id: 2,
        name: "City Medical Center",
        address: "456 Wellness Boulevard, Downtown",
        distance: 2.5,
        rating: 4.5,
        reviews: 890,
        emergencyAvailable: true,
        phone: "+1 (555) 234-5678",
        hours: "24/7 Emergency",
        specialties: ["Emergency Care", "Surgery", "Pediatrics"],
        lat: lat - 0.02,
        lng: lng + 0.015
      },
      {
        id: 3,
        name: "Regional Health Clinic",
        address: "789 Recovery Road, Suburb",
        distance: 3.8,
        rating: 4.2,
        reviews: 567,
        emergencyAvailable: false,
        phone: "+1 (555) 345-6789",
        hours: "8:00 AM - 8:00 PM",
        specialties: ["General Medicine", "Family Practice"],
        lat: lat + 0.03,
        lng: lng - 0.01
      },
      {
        id: 4,
        name: "University Hospital",
        address: "101 Academic Drive, Campus Area",
        distance: 4.2,
        rating: 4.9,
        reviews: 2100,
        emergencyAvailable: true,
        phone: "+1 (555) 456-7890",
        hours: "24/7 Emergency",
        specialties: ["Research", "Specialized Care", "Teaching Hospital"],
        lat: lat - 0.01,
        lng: lng - 0.03
      },
      {
        id: 5,
        name: "Community Care Hospital",
        address: "234 Neighborhood Street, Residential Area",
        distance: 5.1,
        rating: 4.0,
        reviews: 423,
        emergencyAvailable: true,
        phone: "+1 (555) 567-8901",
        hours: "24/7 Emergency",
        specialties: ["Primary Care", "Maternity", "Geriatrics"],
        lat: lat + 0.04,
        lng: lng + 0.02
      }
    ];

    setHospitals(mockHospitals);
    setIsLoading(false);
  };

  const getDirections = (hospital) => {
    // In production, this would open Google Maps with directions
    const url = `https://www.google.com/maps/dir/?api=1&destination=${hospital.lat},${hospital.lng}`;
    window.open(url, '_blank');
  };

  const callHospital = (phone) => {
    window.open(`tel:${phone}`);
  };

  const filteredHospitals = hospitals.filter(hospital => {
    const matchesSearch = hospital.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         hospital.address.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesEmergency = !filterEmergency || hospital.emergencyAvailable;
    return matchesSearch && matchesEmergency;
  });

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Nearby Hospitals</h1>
          <p className="text-gray-600">Find nearby hospitals with real-time availability and navigation</p>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-sm p-6 mb-6"
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search hospitals by name or address..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <button
              onClick={() => setFilterEmergency(!filterEmergency)}
              className={`px-6 py-3 rounded-xl font-semibold flex items-center gap-2 transition-all ${
                filterEmergency
                  ? "bg-red-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <AlertCircle className="w-5 h-5" />
              Emergency Only
            </button>
          </div>
        </motion.div>

        {/* Hospitals List */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredHospitals.map((hospital, index) => (
              <motion.div
                key={hospital.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl shadow-sm p-6 hover:shadow-md transition-shadow"
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-1">{hospital.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      {hospital.address}
                    </div>
                  </div>
                  {hospital.emergencyAvailable && (
                    <div className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-semibold flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      24/7 Emergency
                    </div>
                  )}
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center p-3 bg-emerald-50 rounded-xl">
                    <div className="flex items-center justify-center gap-1 text-emerald-700">
                      <MapPin className="w-4 h-4" />
                      <span className="text-lg font-bold">{hospital.distance}</span>
                    </div>
                    <p className="text-xs text-gray-600">km away</p>
                  </div>
                  <div className="text-center p-3 bg-yellow-50 rounded-xl">
                    <div className="flex items-center justify-center gap-1 text-yellow-700">
                      <Star className="w-4 h-4" />
                      <span className="text-lg font-bold">{hospital.rating}</span>
                    </div>
                    <p className="text-xs text-gray-600">{hospital.reviews} reviews</p>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-xl">
                    <div className="flex items-center justify-center gap-1 text-blue-700">
                      <Clock className="w-4 h-4" />
                      <span className="text-lg font-bold">24/7</span>
                    </div>
                    <p className="text-xs text-gray-600">Hours</p>
                  </div>
                </div>

                {/* Specialties */}
                <div className="mb-4">
                  <p className="text-sm font-semibold text-gray-700 mb-2">Specialties</p>
                  <div className="flex flex-wrap gap-2">
                    {hospital.specialties.map((specialty, idx) => (
                      <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-700 rounded-lg text-xs">
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Contact */}
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
                  <Phone className="w-4 h-4" />
                  <span>{hospital.phone}</span>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button
                    onClick={() => getDirections(hospital)}
                    className="flex-1 py-3 bg-emerald-600 text-white rounded-xl font-semibold hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Navigation className="w-5 h-5" />
                    Get Directions
                  </button>
                  <button
                    onClick={() => callHospital(hospital.phone)}
                    className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <Phone className="w-5 h-5" />
                    Call Now
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {!isLoading && filteredHospitals.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <MapPin className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <p className="text-lg font-medium mb-2">No hospitals found</p>
            <p className="text-sm">Try adjusting your search or filters</p>
          </div>
        )}

        {/* API Key Notice */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 p-4 bg-yellow-50 rounded-xl border border-yellow-200"
        >
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold text-gray-900 mb-1">Google Maps Integration</p>
              <p className="text-sm text-gray-700">
                For production use, add your Google Maps API key to enable real-time location services and accurate hospital data. 
                Get your API key from <a href="https://developers.google.com/maps" target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:underline">Google Cloud Console</a>.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
