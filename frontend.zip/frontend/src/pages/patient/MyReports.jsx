
import { useState } from "react";
import { FileText, Download, Eye } from "lucide-react";

const MyReports = () => {
  const [reports, setReports] = useState([
    {
      id: 1,
      title: "Blood Test Report",
      date: "2024-05-10",
      type: "Blood Report",
      status: "Normal",
    },
    {
      id: 2,
      title: "Chest X-Ray",
      date: "2024-04-25",
      type: "X-Ray",
      status: "Normal",
    },
    {
      id: 3,
      title: "Complete Health Checkup",
      date: "2024-03-15",
      type: "Medical Report",
      status: "All Good",
    },
  ]);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#06402B]">My Reports</h1>
        <p className="text-gray-600 mt-2">View and download your medical reports</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((report) => (
          <div
            key={report.id}
            className="bg-white rounded-[2rem] p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center mb-4">
              <FileText className="text-blue-600" />
            </div>
            <h3 className="font-bold text-[#06402B] mb-2">{report.title}</h3>
            <p className="text-sm text-gray-500 mb-2">{report.type}</p>
            <p className="text-sm text-gray-500 mb-4">{report.date}</p>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
                {report.status}
              </span>
              <div className="flex items-center gap-3">
                <button className="text-gray-500 hover:text-[#06402B]">
                  <Eye className="w-5 h-5" />
                </button>
                <button className="text-gray-500 hover:text-[#06402B]">
                  <Download className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyReports;
