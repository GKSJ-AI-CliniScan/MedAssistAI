
import { useState, useEffect } from "react";
import { User, Mail, Phone, MapPin, Calendar, Droplet, Save } from "lucide-react";
import { useAuth } from "../../hooks/useAuth";
import { authService } from "../../services/authService";

const MyProfile = () => {
  const { user, refresh } = useAuth();
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    phone: "",
    dateOfBirth: "",
    gender: "",
    bloodGroup: "",
    address: "",
    city: "",
    state: "",
    pinCode: "",
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setProfile({
        name: user.name || "",
        email: user.email || "",
        phone: user.phone || "",
        dateOfBirth: user.dateOfBirth || "",
        gender: user.gender || "",
        bloodGroup: user.bloodGroup || "",
        address: user.address || "",
        city: user.city || "",
        state: user.state || "",
        pinCode: user.pinCode || "",
      });
    }
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      await authService.completeProfile(user.id, { ...profile, role: user.role });
      await refresh();
      alert("Profile updated successfully!");
    } catch (err) {
      console.error(err);
      alert("Failed to update profile");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#06402B]">My Profile</h1>
        <p className="text-gray-600 mt-2">View and update your personal & medical information</p>
      </div>

      <div className="bg-white rounded-[2rem] p-8 shadow-sm border border-gray-100">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="text-sm font-semibold text-gray-500 mb-2 block">Full Name</label>
              <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-xl">
                <User className="text-gray-400" />
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="bg-transparent flex-1 outline-none text-[#06402B]"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-gray-500 mb-2 block">Email Address</label>
              <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-xl">
                <Mail className="text-gray-400" />
                <input
                  type="email"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="bg-transparent flex-1 outline-none text-[#06402B]"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-gray-500 mb-2 block">Phone Number</label>
              <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-xl">
                <Phone className="text-gray-400" />
                <input
                  type="text"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  className="bg-transparent flex-1 outline-none text-[#06402B]"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-gray-500 mb-2 block">Date of Birth</label>
              <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-xl">
                <Calendar className="text-gray-400" />
                <input
                  type="date"
                  value={profile.dateOfBirth}
                  onChange={(e) => setProfile({ ...profile, dateOfBirth: e.target.value })}
                  className="bg-transparent flex-1 outline-none text-[#06402B]"
                />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="text-sm font-semibold text-gray-500 mb-2 block">Gender</label>
              <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-xl">
                <User className="text-gray-400" />
                <select
                  value={profile.gender}
                  onChange={(e) => setProfile({ ...profile, gender: e.target.value })}
                  className="bg-transparent flex-1 outline-none text-[#06402B]"
                >
                  <option value="">Select</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-gray-500 mb-2 block">Blood Group</label>
              <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-xl">
                <Droplet className="text-gray-400" />
                <select
                  value={profile.bloodGroup}
                  onChange={(e) => setProfile({ ...profile, bloodGroup: e.target.value })}
                  className="bg-transparent flex-1 outline-none text-[#06402B]"
                >
                  <option value="">Select</option>
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-gray-500 mb-2 block">Address</label>
              <div className="flex items-center gap-3 bg-gray-50 px-4 py-3 rounded-xl">
                <MapPin className="text-gray-400" />
                <input
                  type="text"
                  value={profile.address}
                  onChange={(e) => setProfile({ ...profile, address: e.target.value })}
                  className="bg-transparent flex-1 outline-none text-[#06402B]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-semibold text-gray-500 mb-2 block">City</label>
                <input
                  type="text"
                  value={profile.city}
                  onChange={(e) => setProfile({ ...profile, city: e.target.value })}
                  className="w-full bg-gray-50 px-4 py-3 rounded-xl outline-none text-[#06402B]"
                />
              </div>
              <div>
                <label className="text-sm font-semibold text-gray-500 mb-2 block">Pincode</label>
                <input
                  type="text"
                  value={profile.pinCode}
                  onChange={(e) => setProfile({ ...profile, pinCode: e.target.value })}
                  className="w-full bg-gray-50 px-4 py-3 rounded-xl outline-none text-[#06402B]"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center gap-2 bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-colors disabled:opacity-70"
          >
            <Save className="w-5 h-5" />
            {isSaving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default MyProfile;
